from odoo import models,fields,api,_
import base64
from datetime import datetime,date
from odoo.exceptions import ValidationError
from io import BytesIO

class AccountMove(models.Model):
     _inherit = 'account.move' 

   
     booking_id=fields.Many2one('vb.book.master',string="Booking ID")
     pdf_file = fields.Binary(string="PDF File",size=2048,attachment=True)
     pdf_file_url = fields.Char(string='PDF File URL')
    
     @api.constrains('state')
     def _qr_pdf_code(self):
          for record in self:
               if record.state == 'posted':
                    pdf = self.env.ref('booking_invoice_inherit.action_rate_pesu_invoice_report_document')._render_qweb_pdf(record.id)
                    if pdf:
                         record.pdf_file = base64.b64encode(pdf[0])
                    
     @api.constrains('pdf_file')
     def _compute_pdf_url(self):
          for record in self:
               if record.state == 'posted':
                    base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
                    if record.pdf_file:
                       record.pdf_file_url = f'{base_url}/web/image?model={record._name}&id={record.id}&field=pdf_file'

class account_move_line(models.Model):
    _inherit = 'account.move.line'

    booking_id=fields.Many2one('vb.book.master',string="Booking ID")








